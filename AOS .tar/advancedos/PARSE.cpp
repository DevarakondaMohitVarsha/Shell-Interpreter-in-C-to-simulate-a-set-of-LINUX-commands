#include<bits/stdc++.h>
#include<stdio.h>
#include<conio.h>

using namespace std;



void parsetest(char arr[]){
    int i=0;
    char ps[100][100];
    printf("%s",arr);
    int l=0,m=0,p=0;
    while(arr[l]=='\0' || l<99){
        if(arr[l]!=' '){
            ps[m][p]=arr[l];
            l++;
            p++;
        }
        if(arr[l]==' '){
            ps[m][p]='\0';
            p=0;
            m++;
            while(arr[l]==' '){
                l++;
            }
        }
    }
    for(i=0;strlen(ps[i])!=0;i++)
        printf("\n\t%s",ps[i]);
}

void parseteststripe(char arr[]){
    int i=0;
    char ps[100][100];
    printf("%s",arr);
    int l=0,m=0,p=0;
    while(arr[l]=='\0' || l<99){


        if(arr[l]!=' '){
            ps[m][p]=arr[l];
            l++;
            p++;
        }
        if(arr[l]==' '){
            ps[m][p]='\0';
            p=0;
            m++;
            while(arr[l]==' ' || arr[l]=='|'){
                l++;
            }
        }
    }
    for(i=0;strlen(ps[i])!=0;i++)
        printf("\n\t%s",ps[i]);
}

int main( ) {
    printf("Enter test string to check parser \n");
    char str[100];
    int i;
    int temp = 0;
    scanf("%[^\n]%*c",str);

    for (i=0;str[i]!='\0';i++){
        if(str[i]=='|')
            temp = 1;
    }

    if(temp==1)
        parseteststripe(str);
    else
        parsetest(str);

    return 0;

}



