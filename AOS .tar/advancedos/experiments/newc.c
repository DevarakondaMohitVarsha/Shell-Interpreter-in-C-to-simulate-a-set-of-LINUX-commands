#include<stdio.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<readline/readline.h>
#include<readline/history.h>
#include<time.h>

int main(){
	
	execlp("ls","ls",NULL);
	printf("will not exec");
    return 0;
}


//FIND new
