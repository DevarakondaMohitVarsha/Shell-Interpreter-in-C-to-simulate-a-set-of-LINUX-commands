#include<stdio.h> 
#include<string.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<sys/types.h> 
#include<sys/wait.h> 
#include<readline/readline.h> 
#include<readline/history.h> 
#include<time.h>
#include<dirent.h>

  
#define MAXCOM 1000 // max number of letters to be supported 
#define MAXLIST 100 // max number of commands to be supported

// History is implemented using structures 
struct hist{
    char *hname;	// *hname points to command name
	char hdt[50];  // hdt contains date and time of the commandname
	int  hstat;		// hstat contains status 0=fail 1=success
}histarr[11];

// This value is global and static to keep count of current command
static int hval=0;  

char pwd_for_man[100];

// Function to implement FIND command like grep
void finding_like_grep(char **parsed){
	int i=0,count=0;
	char filenames[1000][100];
	struct dirent *d1;
	DIR *d2 = opendir(".");
    // Uses DIRENT predefined structure to get file names 
	if(d2==NULL){
		printf("error\n");
	}

	// String compare given name with filenames and print if they match
	// Uses strncmp(s1,s2,t) to match substring s1 of size t with given string s2 
	// Here exact match is not considered.
	// Returns more than one result in case of partial matching, like grep.

	while((d1=readdir(d2))!=NULL){
		if(!(strncmp(parsed[1],d1->d_name,strlen(parsed[1])))){
			printf("%s\n",d1->d_name);
			++count;
		}
	}
	if(count==0){
		printf("\n NO Match Found");
		histarr[hval-1].hstat=0;
	}
	else{
		printf("\n %d Matches Found",count);
		histarr[hval-1].hstat=1;
	}
	closedir(d2);

}


// Function to get current working directory
void curwd(){
	histarr[hval-1].hstat=1;
	char curwd[100];
	// Internally uses getcwd(temp_arr_to_store_pwd,size_of_arr) system call	
    getcwd(curwd, sizeof(curwd)); 
    printf("\nCurrent Working Directory is - %s\n", curwd); 
}

// Function to Enter into the shell
void EnterShell(){
	int i;
	while(1){
		// Unless ENTRY is typed, keeps looping before entering the shell
		printf("TO ENTER THE SHELL TYPE <ENTRY> without <>\n");
		i = strcmp("ENTRY",readline(""));
		if(i==0){
			printf("Welcome");
			break;
		}
	}
}





// This is to add status fail or success to the hist structure
void add_stat(int stat){
	if(stat == 1){
		printf("\nSUCCESS");
		histarr[hval-1].hstat = 1;
	}
	else{
		printf("\nFAILURE");
		histarr[hval-1].hstat = 0;
	}
	
}

// Function to print the history
void show_history(){
	// Uses modular counting to get last 10 commands	
	// Modular counting is circular and doesn't overflow the size of hist
    int x=0; int i=0;
	printf("* %35s, %10s, %30s \n","COMMAND NAME ", " STATUS ", " DATE      AND      TIME ");
	printf("* %35s, %10s, %30s \n","------------ ", " ------ ", " ----------------------- ");
	printf("\n");
	histarr[hval-1].hstat=1;
    while(x<11) {
			if(histarr[x].hstat==1){
				if(x==hval-1)
					printf("* -->%32s, %10s, %30s \n",histarr[x].hname,"SUCCESS",histarr[x].hdt);
				else	
					printf("* %35s, %10s, %30s \n",histarr[x].hname,"SUCCESS",histarr[x].hdt);
			}
			else{				
				if(x==hval-1)
					printf("* -->%32s, %10s, %30s \n",histarr[x].hname,"FAILED",histarr[x].hdt);
				else	
					printf("* %35s, %10s, %30s \n",histarr[x].hname,"FAILED",histarr[x].hdt);
			}			
			x++;
    }
	printf("\nCURRENT COMMAND IS POINTED  BY --> \n");
	
}

// Function to get time 
void get_time(){
	// internally implemented inside the header file <time.h>
 	time_t current_time = time(NULL);
	struct tm *tm = localtime(&current_time);
	// asctime(tm) holds the entire date and time as a string
    strcpy(histarr[hval].hdt,asctime(tm));
}

// Function to print manual pages
void manual_page(char **parsed){
	// Just compare the required manual page using strcmp.
	// Followed by opening the file and printing the text on screen.

		//Manual page for CD
	char pwd_temp_man[100];
	getcwd(pwd_temp_man, sizeof(pwd_temp_man));

	if(strcmp(pwd_for_man,pwd_temp_man)!=0){
		printf("\n MAN only works in the directory ~advancedos/\n");
		histarr[hval-1].hstat=0;
	}
	else{
		histarr[hval-1].hstat=1;
	if(!strcmp(parsed[1],"CD")){
		FILE *fp;
		char ch;
		fp = fopen("CD.txt", "r");
		while((ch = getc(fp))!=EOF)
			printf("%c",ch);	
	}
		//Manual page for EXIT
	else if(!strcmp(parsed[1],"EXIT")){
		FILE *fp;
		char ch;
		fp = fopen("EXIT.txt", "r");
		while((ch = getc(fp))!=EOF)
			printf("%c",ch);
	}
		//Manual page for PWD
	else if(!strcmp(parsed[1],"PWD")){
		FILE *fp;
		char ch;
		fp = fopen("PWD.txt", "r");
		while((ch = getc(fp))!=EOF)
			printf("%c",ch);
	}
		//Manual page for FIND
	else if(!strcmp(parsed[1],"FIND")){
		FILE *fp;
		char ch;
		fp = fopen("FIND.txt", "r");
		while((ch = getc(fp))!=EOF)
			printf("%c",ch);
	}
		//Manual page for HISTORY
	else if(!strcmp(parsed[1],"HISTORY")){
		FILE *fp;
		char ch;
		fp = fopen("HISTORY.txt", "r");
		while((ch = getc(fp))!=EOF)
			printf("%c",ch);
	}
	// For manual to work we must be in the same directory where final.c file is in.
	else{
		histarr[hval-1].hstat=0;
		// This is to handle if MAN is followed by wrong command name
		printf("\nCommands supported are CD, HISTORY, EXIT, PWD, MAN, FIND\n");
		printf("\n syntax error.. please type MAN COMMAND_NAME\n");
		printf("\n Please stay in the path /advancedos to access the manual pages\n");
	}
	}
}

  
// Clearing the shell using escape sequences 
// More information about the \033[H\033[J can be seen in README
#define clear() printf("\033[H\033[J") 
  
// Displays the shell startup for 3 seconds
void init_shell() 
{ 
    clear(); 
	printf("\n\n\n\t\tENTERING CUSTOM SHELL");
	// getenv() is used to get the current user name 
    char* username = getenv("USER"); 
    printf("\n\n\n\t\tUSER is: @%s", username); 
    printf("\n\n\n");
	// List of all the commands supported by this shell
	puts(
	"\n\n\nTHE FOLLOWING COMMANDS ARE SUPPORTED BY THIS SHELL\n"     
		"\n* HELP"
        "\n* CD"
		"\n* HISTORY"
		"\n* PWD"
        "\n* EXIT"
		"\n* FIND"
		"\n* MAN" 
		);
	// How long the display has to wait is given by sleep(time) function
    sleep(3); 
    clear(); 
} 
  
// Function to take input 
int read_input_from_terminal(char* str) 
{ 
	// This is used to print the terminal line followed by the cursor to take input
	char terminal_line[1024]; 
    getcwd(terminal_line, sizeof(terminal_line)); 
    printf("\nDir: %s", terminal_line); 
    
	char* buf; 
	// readline() is used to take the user input as a string until enter is pressed
    buf = readline("$ "); 

	// adding the command name to  history
	histarr[hval].hname = buf;
	get_time();

	// When ever a command is added to history we increment the counter
	hval = (hval+1)%11;
    

    if (strlen(buf) != 0) { 
        add_history(buf); 
        strcpy(str, buf); 
		
        return 0; 
    } else { 
        return 1; 
    } 
} 

  
// Function where the system command is executed 
void execute_without_pipeop(char** parsed) 
{ 
    // Forking a child 
    pid_t pid = fork();  
  
    if (pid == -1) { 
        printf("\nFailed forking child.."); 
        return; 
    } else if (pid == 0) { 

		int stat1=execvp(parsed[0], parsed);

        if (stat1 < 0) { 
            printf("\nCould not execute command.."); 
        } 
        exit(stat1); 
    } else { 
        // waiting for child to terminate 
		int stat1;
        wait(&stat1);  
		stat1 = (255-stat1)/255; //since wait value is around 65000, to make it return -1 or 0 we divide it by 255 and subtract 255
		if(stat1>=0){
			add_stat(1);
		}
		else{
			add_stat(0);
			}
        return; 
    } 
} 
  
// Function where the piped system commands is executed 
void execute_with_pipeop(char** parsed, char** parsedpipe) 
{ 
    // 0 is read end, 1 is write end 
    int pipefd[2];  
    pid_t p1, p2; 
  
    if (pipe(pipefd) < 0) { 
        printf("\nPipe could not be initialized"); 
        return; 
    } 
    p1 = fork(); 
    if (p1 < 0) { 
        printf("\nCould not fork"); 
        return; 
    } 
  
    if (p1 == 0) { 
        // Child 1 executing.. 
        // It only needs to write at the write end 
        close(pipefd[0]); 
        dup2(pipefd[1], STDOUT_FILENO); 
        close(pipefd[1]); 
  
        if (execvp(parsed[0], parsed) < 0) { 
            printf("\nCould not execute command 1.."); 
            exit(0); 
        } 
    } else { 
        // Parent executing 
        p2 = fork(); 
  
        if (p2 < 0) { 
            printf("\nCould not fork"); 
            return; 
        } 
  
        // Child 2 executing.. 
        // It only needs to read at the read end 
        if (p2 == 0) { 
            close(pipefd[1]); 
            dup2(pipefd[0], STDIN_FILENO); 
            close(pipefd[0]);

			int stat2 = execvp(parsedpipe[0], parsedpipe);
			 
            if (stat2 < 0) { 
                printf("\nCould not execute command 2.."); 
                exit(stat2); 
            } 
        } else { 
            // parent executing, waiting for two children 
			int stat3,stat4;

            wait(&stat3); 
            wait(&stat4); 
			stat3 = (255-stat3)/255;
			stat4 = (255-stat4)/255;
			if(stat3>=0 && stat4>=0){
				add_stat(1);
			}
			else{
				add_stat(0);
			}
        } 
    } 
} 
  
// HELP command implementation 
void openHelp() 
{ 	
	histarr[hval-1].hstat=1;
    puts(
      	"\n\n**ALL USER DEFINED COMMANDS ARE IN CAPITAL LETTERS"
		"\n**BASIC LINUX COMMNADS ARE ALSO SUPPORTED"
		"\n**USE CAPITAL <MAN COMMANDNAME> WITHOUT <> FOR USER CREATED COMMANDS"
		"\n**USE SMALL   <man commandname> WITHOUT <> FOR LINUX COMMANDS"   
		"\n\n\nTHE FOLLOWING COMMANDS ARE SUPPORTED BY THIS SHELL\n"     
		"\n* HELP"
        "\n* CD"
		"\n* HISTORY"
		"\n* PWD"
        "\n* EXIT"
		"\n* FIND"
		"\n* MAN");  
    return; 
} 

  
// Implementation of user created commands
int user_implemented_commands(char** parsed) 
{ 
    int user_commands_count = 7, i, switch_user_command = 0; 
    char* user_commands_array[user_commands_count]; 
    char* username; 
  
    user_commands_array[0] = "EXIT"; 
    user_commands_array[1] = "CD"; 
    user_commands_array[2] = "HELP"; 
    user_commands_array[3] = "HISTORY";
	user_commands_array[4] = "PWD";
	user_commands_array[5] = "MAN";
	user_commands_array[6] = "FIND";
	
  
    for (i = 0; i < user_commands_count; i++) {
		// Here given command is compared with list of implemented commands  
        if (strcmp(parsed[0], user_commands_array[i]) == 0) { 
            switch_user_command = i + 1; 
            break; 
        } 
    } 
  	// Depending on the command given call the corresponding implementation using switch 
    switch (switch_user_command) { 
    case 1: 
		// Implementation of EXIT
        printf("\nExiting Shell\n"); 
        exit(0); 
    case 2:  
		// Implementation of CD
        chdir(parsed[1]); 
		histarr[hval-1].hstat=1;
        return 1; 
    case 3: 
		// Implementation of HELP
        openHelp(); 
        return 1;  
    case 4:
		// Implementation of HISTORY
		printf("\nlast 10 commands are\n");
		printf("---------------------\n\n");
		show_history();
		return 1;
	case 5:
		// Implementation of PWD
		curwd();
		return 1;
	case 6:
		// Implementation of MAN
		if(!strcmp(parsed[0],"MAN")&&(parsed[1]!=NULL)){
			manual_page(parsed);
		}
		else{
			histarr[hval-1].hstat=0;
			// This is to avoid segmentation error if MAN is not followed by any command name
		printf("\nCommands supported are CD, HISTORY, EXIT, PWD, MAN, FIND\n");
		printf("\n syntax error.. please type MAN COMMAND_NAME\n");
		printf("\n Please stay in the path /advancedos to access the manual pages\n");
		}
		return 1;
	case 7:
		// Implementation of FIND command which works like grep
		if(parsed[1]!=NULL)
			finding_like_grep(parsed);
		else{
			printf("\n SYNTAX error. please type FIND FILENAME \n");
			histarr[hval-1].hstat=0;
		}
		return 1;
    default: 
        break; 
    } 
  
    return 0; 
} 
  
// function to check if there is | operator in the input 
int is_pipeop_in_input(char* str, char** strpiped) 
{ 
    int i; 
    for (i = 0; i < 2; i++) { 

		// strsep(s1,delimiter) is used to seperate string s1 into substrings based on delimiter 
		// delimiter here is | operator

        strpiped[i] = strsep(&str, "|"); 
        if (strpiped[i] == NULL) 
            break; 
    } 
  
    if (strpiped[1] == NULL) 
        return 0; // returns zero if no pipe is found. 
    else { 
        return 1; 
    } 
} 
  
// function for check if there is space " " in the input
void is_space_in_input(char* str, char** parsed) 
{ 
    int i; 
  
    for (i = 0; i < MAXLIST; i++) {

		// strsep(s1,delimiter) is used to seperate string s1 into substrings based on delimiter	
		// delimiter here is space " "

        parsed[i] = strsep(&str, " "); 
  
        if (parsed[i] == NULL) 
            break; 
        if (strlen(parsed[i]) == 0) 
            i--; 
    } 
} 
  

int processString(char* str, char** parsed, char** parsedpipe) 
{ 
  	 
    char* strpiped[2]; 
    int piped = 0; 
  
    piped = is_pipeop_in_input(str, strpiped); 
  	
    if (piped) { 
        is_space_in_input(strpiped[0], parsed); 
        is_space_in_input(strpiped[1], parsedpipe); 
  
    } else { 
  
        is_space_in_input(str, parsed); 
    } 
  
    if (user_implemented_commands(parsed)) 
        return 0; 
    else
        return 1 + piped; 
} 
  
int main() 
{ 
    char inputString[MAXCOM], *arguments_without_pipeop[MAXLIST]; 
    char* arguments_with_pipeop[MAXLIST]; 
    int pipeop_status_flag = 0; 	
    getcwd(pwd_for_man, sizeof(pwd_for_man));
	// before entering the shell type ENTRY     
	EnterShell();

	// initializes the shell display, shows all possible commands, waits for 3 seconds
	init_shell(); 
  
    while (1) { 
		
     
        if (read_input_from_terminal(inputString)) 
            continue; 
        // process 
        pipeop_status_flag = processString(inputString, arguments_without_pipeop, arguments_with_pipeop); 
        // pipeop_status_flag returns 
		// 0 if no command or shell builtin 
        // 1 if command with no pipe operator 
        // 2 if command with pipe operator
  
   
        if (pipeop_status_flag == 1) 
            execute_without_pipeop(arguments_without_pipeop); //execution in case of no pipeoperator
  
        if (pipeop_status_flag == 2) 
            execute_with_pipeop(arguments_without_pipeop, arguments_with_pipeop); // execution with pipeoperator
    } 
    return 0; 
} 

